
// 🌙 ডার্ক মোড টগল
const toggleModeBtn = document.getElementById("toggleMode");
toggleModeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  localStorage.setItem("mode", document.body.classList.contains("dark-mode") ? "dark" : "light");
});

// লোড হলে মোড চেক করো
window.addEventListener("load", () => {
  const savedMode = localStorage.getItem("mode");
  if (savedMode === "dark") {
    document.body.classList.add("dark-mode");
  }

  // 📖 শেষ পড়া পৃষ্ঠা লোড করো
  const lastBook = localStorage.getItem("lastRead");
  if (lastBook && document.getElementById("lastReadBook")) {
    document.getElementById("lastReadBook").textContent = `👉 আপনি শেষ পড়েছেন: ${lastBook}`;
  }
});

// 🌐 ভাষা পরিবর্তন (ডেমো)
const languageSelect = document.getElementById("language");
languageSelect.addEventListener("change", () => {
  const lang = languageSelect.value;
  localStorage.setItem("language", lang);
  alert("ভাষা পরিবর্তনের জন্য পেজ রিলোড করুন!");
});

// 📖 বই পড়া শুরু করলে সেভ করো
function setLastRead(bookTitle) {
  localStorage.setItem("lastRead", bookTitle);
}

// 🔔 Notification ডেমো
const bell = document.getElementById("notificationBell");
if (bell) {
  bell.addEventListener("click", () => {
    alert("🔔 আপনি নতুন কোনো নোটিফিকেশন পাননি।");
  });
}
